console.log('QMOI AI Chromebook app loaded');
document.addEventListener('DOMContentLoaded', function() {
    console.log('App initialized');
});