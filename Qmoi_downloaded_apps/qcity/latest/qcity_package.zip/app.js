if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('service-worker.js').then(reg => {
    console.log('Service Worker registered:', reg);
  }).catch(err => console.log('SW registration failed:', err));
}

console.log('QMOI AI QCity application initialized');
